# 斗地主
This repository is for CS181 Final Project
We design two models for doudizhu AI: MCTS and DQN

## using methods:
python main_ddz.py
in main_ddz.py line14, you can select model from ["random","little_smart","mcts","DQN","manual"]
"manual" represents human moves decided by you!
line22 can change how many round you want to play.
in mcts.py line293, you can change compute_budget
Note: if you choose "DQN" model ,you need to retrain model.

## HAVE FUN!